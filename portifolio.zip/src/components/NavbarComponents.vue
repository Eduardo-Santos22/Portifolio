<template>
  <nav class="bg-fuchsia-800 text-white py-4 px-8 w-full flex justify-between items-center">
    <h1 class="text-lg font-bold">Portifolio Eduardo</h1>
    <ul class="flex gap-6">
      <li>
        <router-link to="/" class="hover:underline">Home</router-link>
      </li>
      <li>
        <router-link to="/sobre" class="hover:underline">Sobre mim</router-link>
      </li>
    </ul>
  </nav>
</template>
