<template>
    <footer class="fixed bottom-0 w-full bg-fuchsia-800 text-white pt-6 text-center mt-12 ">
        <p class="text-sm mt-2 mb-6">Desenvolvido com Vue + Tailwind<br>
        <span class="text-xs">Contato: eduardo245@gmail.com</span>  </p>
    </footer>



    
</template>