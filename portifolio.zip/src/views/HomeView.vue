<script>
</script>

<template>
<div class="mb-25 bg-gray-100 ">
  <h1 class="text-3xl fonty-bold mb-2 mt-6">Olá, meu nome é Eduardo</h1>
  <h1>
    Atualmente estou trabalhando como montador de móveis durante o dia e estudando Análise e Desenvolvimento de Sistemas à noite.<br>
    Tenho 19 anos, e sou interessado por programação. Atualmente penso em me especializar em Java, mas ainda estou longe do meu objetivo.<br>
  </h1>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Sobre mim</h1>
  <p>
    Estou no terceiro termo de Análise e Desenvolvimento de Sistemas, estudo no período noturno e busco constantemente evoluir como programador.<br>
    Tenho me dedicado principalmente ao front-end, aprendendo tecnologias como TailwindCSS, JavaScript e Vue.js.
  </p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Objetivo profissional</h1>
  <p>
    Meu objetivo atual é entrar no mercado de tecnologia como desenvolvedor front-end e, no futuro, evoluir para full-stack com foco em Java.
  </p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Habilidades que estou desenvolvendo</h1>
  <ul class="list-disc list-inside">
    <li>HTML, CSS e JavaScript</li>
    <li>Vue.js e TailwindCSS</li>
    <li>Git e GitHub</li>
  </ul>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Estudando atualmente</h1>
  <ul class="list-disc list-inside">
    <li>Frameworks front-end (Vue.js)</li>
    <li>Estilização com Tailwind</li>
    <li>Lógica de programação e fundamentos de Java</li><br><br>
  </ul>
</div>


</template>