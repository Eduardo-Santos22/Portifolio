<template>
<div class="pb-25">
  <h1 class="text-4xl fonty-bold mb-2 mt-6"> Sobre Mim</h1>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Nome completo</h1>
  <p>Eduardo Santos da Silva</p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Idade e localização</h1>
  <p>19 anos — Guaimbê, SP</p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Descrição pessoal</h1>
  <p>
    Sou uma pessoa dedicada e curiosa, apaixonada por tecnologia e resolução de problemas. Durante o dia trabalho como montador de móveis, e à noite estudo Análise e Desenvolvimento de Sistemas. <br>
    Tenho grande interesse por programação e pretendo me especializar em Java no futuro, além de continuar aprendendo sobre desenvolvimento front-end com JavaScript, Vue.js e Tailwind.
  </p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Nível de escolaridade</h1>
  <p>
    Cursando o 3º termo de Análise e Desenvolvimento de Sistemas (período noturno).
  </p>

  <h1 class="text-2xl fonty-bold mb-2 mt-6"> Idiomas</h1>
  <p>
    Português (nativo)<br>
    Inglês (básico/intermediário - em aprendizado)
  </p>
</div>

</template>

